package Assignments;

import java.util.Scanner;

public class ArmStrong {

	public static void main(String[] args) {
		
		int num;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number: ");
		num=sc.nextInt();
		
		int sum = 0;
		int armNum = num;
		int countDigit = num;
		int count = 0;
		
		while (countDigit != 0) {        //counting the number of digits
			countDigit = countDigit/10;
			count++;
		}
		while (armNum != 0) {            // logic for Armstrong
            int digit = armNum % 10;
            sum = sum + (int) Math.pow(digit, count);
            armNum = armNum / 10;
        }
		
		if(num==sum) {
			System.out.println("Number is a Armstrong Number");
		}else {
			System.out.println("Number is not a Armstrong Number");
		}
	}

}
