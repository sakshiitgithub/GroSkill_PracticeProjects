package Assignments;

import java.util.Scanner;

public class SumOfOddNumbers {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

        System.out.print("Enter the starting number: ");
        int start = sc.nextInt();

        System.out.print("Enter the ending number: ");
        int end = sc.nextInt();

        int sum = 0;
        int i = start;

        System.out.println("Odd numbers in the given range are: ");

        
        do {
            if (i % 2 != 0)       //checking if the number is odd
            {             
                System.out.print(i + " ");
                sum = sum + i;
            }
            
            i++; 
        } 
        
        while (i <= end);

        System.out.println("\nSum of all odd numbers from " + start + " to " + end + " is: " + sum);

        sc.close();

	}

}
