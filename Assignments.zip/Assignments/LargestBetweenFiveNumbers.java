package Assignments;

import java.util.Scanner;

public class LargestBetweenFiveNumbers {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter first number: ");
		int a = sc.nextInt();
		
		System.out.println("Enter second number: ");
		int b = sc.nextInt();
		
		System.out.println("Enter third number: ");
		int c = sc.nextInt();
		
		System.out.println("Enter fourth number: ");
		int d = sc.nextInt();
		
		System.out.println("Enter fifth number: ");
		int e = sc.nextInt();
		
		if (a >= b && a >= c && a >= d && a >= e) {
            System.out.println("a is max");
        } 
        else if (b >= a && b >= c && b >= d && b >= e) {
            System.out.println("b is max");
        } 
        else if (c >= a && c >= b && c >= d && c >= e) {
            System.out.println("c is max");
        } 
        else if (d >= a && d >= b && d >= c && d >= e) {
            System.out.println("d is max");
        } 
        else {
            System.out.println("e is max");
        }

	}

}
