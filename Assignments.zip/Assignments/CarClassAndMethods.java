package Assignments;

class Car
{
	String brand;
	
	Car()
	{
		brand="â€œFordâ€.";
	}
	
	String getBrand()
	{
		return brand;
	}
}

public class CarClassAndMethods {

	public static void main(String[] args) {
		
		Car c = new Car();
		String brandOfCar = c.getBrand();
		System.out.println("Brand of the car: " + brandOfCar);
		
  }

}
