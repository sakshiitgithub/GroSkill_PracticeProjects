package Assignments;

import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
		
        int num, fact=1;
		
		System.out.println("Enter a Number: ");
		
		Scanner sc=new Scanner(System.in);
		num=sc.nextInt();
		
		//Ascending order
//		for(int i=1;i<=num;i++)
//		{
//			fact=fact*i;
//		}
//		
//		System.out.println("Factorial of a given number is: "+fact);
		
		//Descending order
		for(int i=num;i>=1;i--)  //i=5>=1,i=4>=1,i=3>=1,i=2>=1,i=1>=1
		{
			fact=fact*i;   //1*5=5,5*4=20,20*3=60,60*2=120,120*1=120
		}
		
		System.out.println("Factorial of a given number is: "+fact);

	}

}
