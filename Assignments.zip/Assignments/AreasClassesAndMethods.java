package Assignments;

class Shape
{
	double length;
	
	Shape(double length) {
        this.length = length;
    }
	
	void square()
	{
		double area = length * length;
	    System.out.println("Area of Square is: " + area);
	}
	
	void rectangle(double width)
	{
		double area = length * width;
		System.out.println("Area of Rectangle is: " + area);
	}
	
	void circle()
	{
		double area = 3.14 * length * length;            //Using length as radius
		System.out.println("Area of Circle is: " + area);
	}
}


public class AreasClassesAndMethods {

	public static void main(String[] args) {
		
		Shape sp= new Shape(4);
		sp.square();
		sp.rectangle(5);
		sp.circle();

	}

}
