package Assignments;

import java.util.Scanner;

public class DiamondPattern {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of rows for the diamond: ");
        int row = sc.nextInt();
        
        for(int i=0;i<row;i++)
        {
        	for(int j=0;j<row-i-1;j++)    //Printing spaces
        	{
        		System.out.print(" ");
        	}
        	
        	for(int j=0;j<=i;j++)     //Printing stars
        	{
        		System.out.print("* ");
        	}
        	
        	System.out.println();
        }
        
        for(int i=0;i<row-1;i++)
        {
        	for(int j=0;j<=i;j++)      //Printing spaces
        	{
        		System.out.print(" ");
        	}
        	for(int j=0;j<row-i-1;j++)     //Printing stars
        	{
        		System.out.print("* ");
        	}
        	
        	System.out.println();
        }

        
	}

}
