package Assignments;

class Schooll
{
	String name;
	String address;
	int strength;
	
	Schooll(String name, String address)
	{
		this.name=name;
		this.address=address;
	}
	
	Schooll(String name, String address, int strength)
	{
		this.name=name;
		this.address=address;
		this.strength=strength;
	}
	
	void display()
	{
		 System.out.println("School Name: " + name);
	     System.out.println("School Address: " + address);
	     System.out.println("School Strength: " + strength);
	}
}

public class MethodClassAndConstructorQue2 {

	public static void main(String[] args) {
		Schooll sc1 = new Schooll("Gulab Glory School", "Udaipur");
		sc1.display();
		
		Schooll sc2 = new Schooll("Gulab Glory School", "Udaipur", 5000);
		sc2.display();

	}

}
