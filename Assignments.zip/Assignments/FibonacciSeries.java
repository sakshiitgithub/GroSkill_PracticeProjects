package Assignments;

public class FibonacciSeries {

	public static void main(String[] args) {
		
        int n1=0,n2=1,n3;
		
		int range=6;
		
		System.out.print(n1+" ");  //0
		System.out.print(n2+" ");  //1
		
		for (int i=0;i<range;i++)  //i=0<6,i=1<6,i=2<6,i=3<6,i=4<6,i=5<6,(i=6<6 - Condition false)
		{
			n3=n1+n2;       //n3=0+1=1,n3=1+1=2,n3=1+2=3,n3=2+3=5,n3=3+5=8,n3=5+8=13
			System.out.print(n3+" "); //1,2,3,5,8,13
			n1=n2;         //n1=1,n1=1,n1=2,n1=3,n1=5,n1=8
			n2=n3;        //n2=1,n2=2,n2=3,n2=5,n2=8,n2=13
		}
   }

}
