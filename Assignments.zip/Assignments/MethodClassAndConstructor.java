package Assignments;

class School
{
	String name;
	
	School()
	{
		name = "Gulab Glory Senior Secondary School";
		System.out.println("School Name: " + name);
	}
	
	void displayMessage()
	{
	    System.out.println("This School is based out of Kolkata");
	}
}

public class MethodClassAndConstructor {

	public static void main(String[] args) {
		
		School sc = new School();      // calls the default constructor
		sc.displayMessage();           // calls the method

	 }
}
