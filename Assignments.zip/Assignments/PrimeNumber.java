package Assignments;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args) {
		
		int num, count=0;
		
		System.out.println("Enter a Number: ");
		
		Scanner sc=new Scanner(System.in);
		num=sc.nextInt();
		
		for(int i=1;i<=num;i++)//1<=3,2<=3,3<=3,4<=3-Condition false
		{
			if(num%i==0) //3%1=0,3%2=1-Condition false,3%3=0
			{
				count++; //1,2
			}
		}
		
		if(count==2)
		{
			System.out.println("Number is Prime");
		} else {
			System.out.println("Number is not Prime");
		}

	}

}
