package Assignments;

import java.util.Scanner;

public class GCDOfTwoNumbers {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any two numbers: ");
		int a=sc.nextInt();
		int b=sc.nextInt();
		
		int greatestCommonDivisor=0;
		
		for(int i=1;i<=a;i++)
		{
			if(a%i==0 && b%i==0)           //finding common factors
			{
				greatestCommonDivisor=i;
			}
		}
		
		System.out.println("GCD of two numbers: " + greatestCommonDivisor);

	}

}
