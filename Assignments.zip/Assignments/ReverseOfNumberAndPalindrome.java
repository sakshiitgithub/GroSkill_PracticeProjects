package Assignments;

import java.util.Scanner;

public class ReverseOfNumberAndPalindrome {

	public static void main(String[] args) {
		
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number: ");
        int num = sc.nextInt();
		
		int originalNum=num, rev=0;
		
		while(num!=0)
		{
			int digit = num%10;
			rev=rev*10+digit;
			num=num/10;
		}
		
		System.out.println("Reverse of number is "+rev);
		
		if(originalNum==rev)
		{
			System.out.println("It is a Palindrome");
		}
		else
		{
			System.out.println("It is not a Palindrome");
		}

	}

}
