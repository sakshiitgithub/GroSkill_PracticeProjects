package Assignments;

import java.util.Scanner;

public class AmountAndSI {

	public static void main(String[] args) {
		
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter Principal amount P: ");
        double P = sc.nextDouble();
        
        System.out.print("Enter Rate of interest R: ");
        double R = sc.nextDouble();
        
        System.out.print("Enter Time in years T: ");
        double T = sc.nextDouble();
        
        double SI = (P * R * T) / 100;   // Simple Interest formula
        
        double Amount = P + SI;         // Amount formula
        
        System.out.println("Simple Interest SI: " + SI);
        System.out.println("Total Amount A: " + Amount);
        
        sc.close();

	}

}
